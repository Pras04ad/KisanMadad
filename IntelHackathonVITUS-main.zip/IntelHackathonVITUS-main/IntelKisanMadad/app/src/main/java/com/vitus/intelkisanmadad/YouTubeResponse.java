package com.vitus.intelkisanmadad;

import java.util.List;

public class YouTubeResponse {
    public List<YouTubeVideoItem> items;
}
